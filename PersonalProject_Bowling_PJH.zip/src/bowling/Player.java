package bowling;

import java.util.Scanner;

public class Player {
	Scanner scan = new Scanner(System.in);
	String next;
	
	ScoreBoard scoreBoard = new ScoreBoard();
	
	int maxScore = 10;
	int score1 = 0;
	int score2 = 0;
	int score3 = 0;

	public void throwBall_1(int throwCount) {
		// 첫 투구 점수 생성: 0~10 사이의 난수
//		score1 = (int)(Math.random() * (maxScore + 1));
		score1 = 10;	//TEST: 지정한 점수 생성
		
		// 투구 결과를 각 용도별 점수판에 입력
		scoreBoard.throwIntArr[throwCount-1] = score1; 
		scoreBoard.frameScoreArr[(throwCount-1)/2] = score1;
		
		if (score1 == 0) {
			scoreBoard.throwStrArr[throwCount-1] = "-";
		} else if (score1 == maxScore) {
			scoreBoard.throwStrArr[throwCount-1] = "X";
		} else if (score1 > 0 && score1 < maxScore){
			scoreBoard.throwStrArr[throwCount-1] = score1 + "";
		}
	}
	
	public void throwBall_2(int throwCount) {
		// 두 번째 투구 점수 생성: 0~10 사이의 난수 or 0~(10-score1) 사이의 난수
		if (throwCount < 19) {
			score2 = (int)(Math.random() * (maxScore - score1) + 1);
		} else if (throwCount >= 19 && score1 == 10) {
			score2 = (int)(Math.random() * (maxScore + 1));
		} else if (throwCount >= 19 && score1 < 10) {
			score2 = (int)(Math.random() * (maxScore - score1) + 1);
		}
		score2 = 10;	// TEST: 지정한 점수 생성
		
		// 투구 결과를 각 용도별 점수판에 입력
		scoreBoard.throwIntArr[throwCount-1] = score2;
		scoreBoard.frameScoreArr[(throwCount-1)/2] = score1 + score2; 
		
		if (score2 == 0) {
			scoreBoard.throwStrArr[throwCount-1] = "-";
		} else if (throwCount-1 == 19 && score2 == maxScore) {
			scoreBoard.throwStrArr[throwCount-1] = "X";
		} else if (score1 + score2 == maxScore) {
			scoreBoard.throwStrArr[throwCount-1] = "/";
		} else {
			scoreBoard.throwStrArr[throwCount-1] = score2 + "";
		}
	}
	
	public void throwBall_3(int throwCount) {
		// 세 번째 투구 점수 생성: 0~10 사이의 난수 or 0~(10-직전 투구 득점) 사이의 난수
		if (score1 + score2 == 10 || score1 == 10 && score2 == 10) {
			score3 = (int)(Math.random() * (maxScore + 1));
		} else if(score1 == 10 && score2 != 10) {
			score3 = (int)(Math.random() * (maxScore - score2) + 1);
		}
		score3 = 10;	// TEST: 지정한 점수 생성
		
		// 투구 결과를 각 용도별 점수판에 입력
		scoreBoard.throwIntArr[throwCount-1] = score3;	// 생성된 점수 할당
		
		if (score3 == 0) {
			scoreBoard.throwStrArr[throwCount-1] = "-";
		} else if (score3 == maxScore) {
			scoreBoard.throwStrArr[throwCount-1] = "X";
		} else {
			scoreBoard.throwStrArr[throwCount-1] = score3 + "";
		}
	}

}	// end of class
