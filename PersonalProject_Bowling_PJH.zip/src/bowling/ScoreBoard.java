package bowling;

import java.util.Scanner;

public class ScoreBoard {
	Scanner scan = new Scanner(System.in);
	String next;
	
	int maxScore = 10;
	
	String scoreBoardLine = "-------------------------------------"
			+ "-----------------------------------------------------------";
	String scoreBoardFrameIndex = 
			"    FRAME\t 1\t 2\t 3\t 4\t 5\t 6\t 7\t 8\t 9\t 10";
	
	// X, / 처리시 출력되는 그림
	String picStrike = "\r\n"
			+ " .d8888b.      88888888888     8888888b.      8888888     888    d8P      8888888888     888     888 \r\n"
			+ "d88P  Y88b         888         888   Y88b       888       888   d8P       888            888     888 \r\n"
			+ "Y88b.              888         888    888       888       888  d8P        888            888     888 \r\n"
			+ " \"Y888b.           888         888   d88P       888       888d88K         8888888        888     888 \r\n"
			+ "    \"Y88b.         888         8888888P\"        888       8888888b        888            888     888 \r\n"
			+ "      \"888         888         888 T88b         888       888  Y88b       888            Y8P     Y8P \r\n"
			+ "Y88b  d88P         888         888  T88b        888       888   Y88b      888             \"       \"  \r\n"
			+ " \"Y8888P\"          888         888   T88b     8888888     888    Y88b     8888888888     888     888 \r\n"
			+ "                                                                                                     \r\n"
			+ "                                                                                                     \r\n"
			+ "                                                                                                     \r\n"
			+ "";
	String picSpare = "\r\n" + "\t .d8888b.      8888888b.         d8888     8888888b.      8888888888     888 \r\n"
			+ "\td88P  Y88b     888   Y88b       d88888     888   Y88b     888            888 \r\n"
			+ "\tY88b.          888    888      d88P888     888    888     888            888 \r\n"
			+ "\t \"Y888b.       888   d88P     d88P 888     888   d88P     8888888        888 \r\n"
			+ "\t    \"Y88b.     8888888P\"     d88P  888     8888888P\"      888            888 \r\n"
			+ "\t      \"888     888          d88P   888     888 T88b       888            Y8P \r\n"
			+ "\tY88b  d88P     888         d8888888888     888  T88b      888             \"  \r\n"
			+ "\t \"Y8888P\"      888        d88P     888     888   T88b     8888888888     888 \r\n"
			+ "\t                                                                             \r\n"
			+ "\t                                                                             \r\n"
			+ "\t                                                                             \r\n" + "";

	// 점수 배열: 계산, 출력 등 다양한 용도
	int[] throwIntArr = new int[21];
	String[] throwStrArr = new String[21];
	int[] frameScoreArr = new int[10];
	int[] totalScoreArr = new int[10];
	
	// 1. 점수 계산 메서드
	public void calculateFrameScore() {

		// 1-1. 프레임별 점수 계산
		for (int i = 0; i < throwIntArr.length - 3; i += 2) {
//			1) 3연속 X(turkey) => 한 프레임 최대 점수인 30점
			if (throwStrArr[i] == "X" && throwStrArr[i + 2] == "X" && throwStrArr[i + 4] == "X") {
				frameScoreArr[i / 2] = 30;
			}
//			2) 2연속 X(double) => 해당 프레임 10 + 다음 프레임 10 + 다다음프레임 첫 투구까지 합산
			else if (throwStrArr[i] == "X" && throwStrArr[i + 2] == "X" && throwStrArr[i + 4] != "X") {
				frameScoreArr[i / 2] = 20 + throwIntArr[i + 4];
			}
//			3) 단일 X: 다음프레임 점수까지 합산			
			else if (throwStrArr[i] == "X" && throwStrArr[i + 2] != "X" && i < 18) {
				frameScoreArr[i / 2] = 10 + throwIntArr[i + 2] + throwIntArr[i + 3];
			}
//			4) /: 다음프레임 첫 투구 점수까지 합산
			else if (throwStrArr[i + 1] == "/") {
				frameScoreArr[i / 2] = 10 + throwIntArr[i + 2];
			}
//			5) X, / 가 없는 경우 : 해당 프레임의 두 투구 점수 합산
			else {
				frameScoreArr[i / 2] = throwIntArr[i] + throwIntArr[i + 1];
			}
//		6) 10번 프레임은 다음 프레임이 없기 때문에, 단순히 해당 프레임의 점수를 합산한다.
		}
		frameScoreArr[9] = throwIntArr[18] + throwIntArr[19] + throwIntArr[20];

		// 1-2. 누적 점수 계산
		totalScoreArr[0] = frameScoreArr[0];
		for (int i = 1; i < totalScoreArr.length; i++) {
			totalScoreArr[i] = frameScoreArr[i] + totalScoreArr[i - 1];
		}
	}

	// 2-1. 투구1 결과 출력 메서드
	public void showThrowScore_1(int throwCount) {
		System.out.print("\t\t\t\t\t첫 번째 투구.... ");
		next = scan.nextLine();
		System.out.println("\t\t\t\t\t\t\t" + throwIntArr[throwCount-1]);
		
		// 0점은 "Gutter", 10점은 "Strike" 문구 출력
		if (throwIntArr[throwCount - 1] == 0) {
			System.out.print("\t\t\t\t\t    G U T T E R 😭 \n");
		} else if (throwIntArr[throwCount - 1] == maxScore) {
			System.out.print(picStrike);
		}
		
		System.out.println();
		next = scan.nextLine();
	}

	// 2-2. 투구2 결과 출력 메서드
	public void showThrowScore_2(int throwCount) {
		System.out.print("\t\t\t\t\t두 번째 투구.... ");
		next = scan.nextLine();
		System.out.println("\t\t\t\t\t\t\t" + throwIntArr[throwCount-1]);
		
		// 0점은 "Gutter", 10점은 "Spare" 문구 출력
		if (throwIntArr[throwCount - 1] == 0) {
			System.out.print("\t\t\t\t\t    G U T T E R 😭 \n");
		} else if (throwIntArr[throwCount - 2] + throwIntArr[throwCount - 1] == maxScore) {
			System.out.print(picSpare);
		}
		if (throwCount == 20 && throwIntArr[throwCount - 1] == maxScore) {
			System.out.print(picStrike);
		}
		
		System.out.println();
		next = scan.nextLine();
	}

	// 2-3. 투구3 결과 출력 메서드
	public void showThrowScore_3(int throwCount) {
		System.out.print("\t\t\t\t\t세 번째 투구.... ");
		next = scan.nextLine();
		System.out.println("\t\t\t\t\t\t\t" + throwIntArr[throwCount-1]);
		
		// 0점은 "Gutter", 10점은 "Strike" 문구 출력
		if (throwIntArr[throwCount - 1] == 0) {
			System.out.print("\t\t\t\t\t    G U T T E R 😭 \n");
		} else if (throwIntArr[throwCount-1] == maxScore) {
			System.out.print(picStrike);
		}
		
		System.out.println();
		next = scan.nextLine();
	}

	// 3. 스코어보드 출력 메서드
	public void showScoreBoard(int throwCount) {

		calculateFrameScore();
		System.out.println(scoreBoardLine);
		System.out.println(scoreBoardFrameIndex);
		System.out.println(scoreBoardLine);

		// 3-1. 투구별 점수 출력
		System.out.print("   투구별 점수 \t");
		for (int i = 0; i < throwStrArr.length; i++) {
			if (throwStrArr[i] == null) { // 진행되지 않은 프레임: null로 초기화되어있음.
				throwStrArr[i] = " "; // null 대신 공백으로 출력.
			} else {
				System.out.print(throwStrArr[i] + " ");
			}
			if (i % 2 == 1 && i != 19) { // 홀수번 투구 후 띄어 출력하되, 10프레임 세 번째 점수는 띄우지 않음
				System.out.print("\t");
			}
		}
		System.out.println();

		// 3-2. 프레임별 점수 출력 ------- 실제 게임에서는 출력되지 않음
		System.out.print("프레임별 점수 \t ");
		for (int i = 0; i < throwCount/2; i++) {
			System.out.print(frameScoreArr[i] + "\t ");
		}
		System.out.println();
		
		// 3-3. 누적 점수 출력
		System.out.print("      누적 점수\t ");
		for (int i = 0; i < throwCount/2; i++) {
			System.out.print(totalScoreArr[i] + "\t ");
		}
		System.out.println();
		System.out.println(scoreBoardLine);
		System.out.println();
	}

} // end of class
