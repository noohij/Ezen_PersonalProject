package bowling;
// 진행되지 않은 프레임의 점수가 0 또는 null으로 출력됨 //
// 모든 프레임 점수, 누적 점수가 모두 마지막 점수로 출력되는 문제 // 
// 10프레임에서 스페어처리 했는데 3번째 투구 진행되지 않음 //
// 상황별 아스키아트 추가 //
// 객체별 기능 명확한 분리 ??

import java.util.Scanner;

public class BowlingSystem {

	public void gameStart() {

		Scanner scan = new Scanner(System.in);

		Player player = new Player();

		int throwCount = 0;

		System.out.println("게임을 진행하려면 Enter를 누르세요.");
		String next = scan.nextLine();
		System.out.println("\r\n" + 
				"              _____    ___   ___  ___  _____     _____   _____    ___   ______   _____ \r\n" + 
				"             |  __ \\  / _ \\  |  \\/  | |  ___|   /  ___| |_   _|  / _ \\  | ___ \\ |_   _|\r\n" + 
				"             | |  \\/ / /_\\ \\ | .  . | | |__     \\ `--.    | |   / /_\\ \\ | |_/ /   | |  \r\n" + 
				"             | | __  |  _  | | |\\/| | |  __|     `--. \\   | |   |  _  | |    /    | |  \r\n" + 
				"             | |_\\ \\ | | | | | |  | | | |___    /\\__/ /   | |   | | | | | |\\ \\    | |  \r\n" + 
				"              \\____/ \\_| |_/ \\_|  |_/ \\____/    \\____/    \\_/   \\_| |_/ \\_| \\_|   \\_/  \r\n" + 
				"                                                                                       \r\n" + 
				"                                                                                       \r\n" + 
				"");
		
		// 게임 시작: 10프레임 수행
		for (int i = 0; i < 10; i++) {
			next = scan.nextLine();
			System.out.println(" ========================================   "
							+ (i + 1) + " 프레임       ============================================");
			System.out.println();
			next = scan.nextLine();

			// 프레임 내 첫 투구
			throwCount++;
			player.throwBall_1(throwCount);

			// 첫 투구 점수 확인
			player.scoreBoard.showThrowScore_1(throwCount);
			
			// 첫 투구에서 X 실패 => 두 번째 투구 진행.
			if (player.score1 != 10) {
				// 두 번째 투구
				throwCount++;
				player.throwBall_2(throwCount);

				// 두 번째 투구 점수 확인
				player.scoreBoard.showThrowScore_2(throwCount);
				
			// 1~9프레임에서 첫 투구 X => 다음 프레임으로.
			} else if (throwCount < 19 && player.score1 == 10) {
				throwCount++; // throwCount의 throw는 반프레임을 의미
				// 프레임 종료시 프레임 점수 출력
				player.scoreBoard.showScoreBoard(throwCount);
				continue;
				
			// 10프레임에서 첫 투구 X => 두 번째 투구 진행.
			} else if (throwCount == 19 && player.score1 == 10) {
				throwCount++;
				player.throwBall_2(throwCount);

				player.scoreBoard.showThrowScore_2(throwCount);
			}

			if (throwCount < 19) { // 1~9프레임에서 두 번째 투구 마무리
				// 프레임 종료시 프레임 점수 출력
				player.scoreBoard.showScoreBoard(throwCount);
				continue; //다음 프레임으로.
				
				// 10프레임에서 첫 투구 X였거나 두 번째 투구가 X가 아니면 세 번째 투구 진행
			} else if (throwCount >= 19 && player.score1 + player.score2 >= 10) { 
				throwCount++;
				player.throwBall_3(throwCount);
				player.scoreBoard.showThrowScore_3(throwCount);
			}

			// 프레임 종료시 프레임 점수 출력
			player.scoreBoard.showScoreBoard(throwCount);
			
			next = scan.nextLine();

		} // end of for, 게임 종료

		// 게임 종료 시 최종 스코어 출력
		System.out.println(
				"******************************************     최종 스코어     *****************************************");
		System.out.println(
				"******************************************       " + player.scoreBoard.totalScoreArr[9] + "      *****************************************");
		
		// 최종 스코어 300점 기록 시 PERFECT GAME 배너 출력, 그 외 GAME OVER
		if (player.scoreBoard.totalScoreArr[9] == 300) {
			System.out.println("\r\n"
					+ "   \t______  _____ ______ ______  _____  _____  _____     _____   ___  ___  ___ _____ \r\n"
					+ "   \t| ___ \\|  ___|| ___ \\|  ___||  ___|/  __ \\|_   _|   |  __ \\ / _ \\ |  \\/  ||  ___|\r\n"
					+ "   \t| |_/ /| |__  | |_/ /| |_   | |__  | /  \\/  | |     | |  \\// /_\\ \\| .  . || |__  \r\n"
					+ "   \t|  __/ |  __| |    / |  _|  |  __| | |      | |     | | __ |  _  || |\\/| ||  __| \r\n"
					+ "   \t| |    | |___ | |\\ \\ | |    | |___ | \\__/\\  | |     | |_\\ \\| | | || |  | || |___ \r\n"
					+ "   \t\\_|    \\____/ \\_| \\_|\\_|    \\____/  \\____/  \\_/      \\____/\\_| |_/\\_|  |_/\\____/ \r\n"
					+ "   \t                                                                                 \r\n"
					+ "   \t                                                                                 \r\n" + "");
		} else {
			System.out.println("\r\n" + 
					"                  _____    ___   ___  ___  _____     _____   _   _   _____  ______ \r\n" + 
					"                 |  __ \\  / _ \\  |  \\/  | |  ___|   |  _  | | | | | |  ___| | ___ \\\r\n" + 
					"                 | |  \\/ / /_\\ \\ | .  . | | |__     | | | | | | | | | |__   | |_/ /\r\n" + 
					"                 | | __  |  _  | | |\\/| | |  __|    | | | | | | | | |  __|  |    / \r\n" + 
					"                 | |_\\ \\ | | | | | |  | | | |___    \\ \\_/ / \\ \\_/ / | |___  | |\\ \\ \r\n" + 
					"                  \\____/ \\_| |_/ \\_|  |_/ \\____/     \\___/   \\___/  \\____/  \\_| \\_|\r\n" + 
					"                                                                                   \r\n" + 
					"                                                                                   \r\n" + 
					"");
		}
	}
} // end of class
