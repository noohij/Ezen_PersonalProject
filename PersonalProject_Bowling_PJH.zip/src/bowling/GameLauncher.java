package bowling;

public class GameLauncher {
	
	public static void main(String[] args) {
		
		BowlingSystem game1 = new BowlingSystem();
		
		game1.gameStart();
		
	}
	
}
